import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;

public class ModernPong extends JPanel implements ActionListener, KeyListener {
    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;
    private static final int PADDLE_WIDTH = 15;
    private static final int PADDLE_HEIGHT = 90;
    private static final int BALL_SIZE = 20;
    
    private int paddle1Y = HEIGHT / 2 - PADDLE_HEIGHT / 2;
    private int paddle2Y = HEIGHT / 2 - PADDLE_HEIGHT / 2;
    private double ballX = WIDTH / 2 - BALL_SIZE / 2;
    private double ballY = HEIGHT / 2 - BALL_SIZE / 2;
    private double ballXSpeed = 5;
    private double ballYSpeed = 5;
    
    private int score1 = 0;
    private int score2 = 0;
    
    private boolean upPressed = false;
    private boolean downPressed = false;
    private boolean wPressed = false;
    private boolean sPressed = false;

    // Modern features
    private Color currentBallColor = Color.WHITE;
    private ArrayList<PowerUp> powerUps = new ArrayList<>();
    private Random random = new Random();
    private Timer powerUpSpawnTimer;
    private int paddle1Height = PADDLE_HEIGHT;
    private int paddle2Height = PADDLE_HEIGHT;
    private float ballSpeedMultiplier = 1.0f;

    private class PowerUp {
        int x, y;
        Color color;
        String type;

        PowerUp(int x, int y, String type) {
            this.x = x;
            this.y = y;
            this.type = type;
            switch(type) {
                case "SPEED":
                    this.color = Color.YELLOW;
                    break;
                case "SIZE":
                    this.color = Color.GREEN;
                    break;
                case "SLOW":
                    this.color = Color.BLUE;
                    break;
            }
        }
    }

    public ModernPong() {
        System.out.println("MODERN PONG - The Next Generation");
        System.out.println("--------------------------------");
        System.out.println("A modern take on the classic game with power-ups and effects!");
        System.out.println("\nPower-ups:");
        System.out.println("Yellow - Speed Up Ball");
        System.out.println("Green  - Increase Paddle Size");
        System.out.println("Blue   - Slow Down Ball");
        System.out.println("\nControls:");
        System.out.println("Player 1 (Left): W/S keys");
        System.out.println("Player 2 (Right): Up/Down arrow keys\n");
        
        this.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        this.setBackground(Color.BLACK);
        this.setFocusable(true);
        this.addKeyListener(this);
        
        Timer gameTimer = new Timer(16, this);
        gameTimer.start();

        powerUpSpawnTimer = new Timer(5000, e -> spawnPowerUp());
        powerUpSpawnTimer.start();
    }

    private void spawnPowerUp() {
        if (powerUps.size() < 3) {
            int x = random.nextInt(WIDTH - 200) + 100;
            int y = random.nextInt(HEIGHT - 100) + 50;
            String[] types = {"SPEED", "SIZE", "SLOW"};
            powerUps.add(new PowerUp(x, y, types[random.nextInt(types.length)]));
        }
    }

    private void checkPowerUpCollisions() {
        Rectangle ballRect = new Rectangle((int)ballX, (int)ballY, BALL_SIZE, BALL_SIZE);
        for (int i = powerUps.size() - 1; i >= 0; i--) {
            PowerUp powerUp = powerUps.get(i);
            Rectangle powerUpRect = new Rectangle(powerUp.x, powerUp.y, 20, 20);
            
            if (ballRect.intersects(powerUpRect)) {
                applyPowerUp(powerUp);
                powerUps.remove(i);
            }
        }
    }

    private void applyPowerUp(PowerUp powerUp) {
        switch(powerUp.type) {
            case "SPEED":
                ballSpeedMultiplier = 1.5f;
                Timer speedTimer = new Timer(5000, e -> ballSpeedMultiplier = 1.0f);
                speedTimer.setRepeats(false);
                speedTimer.start();
                break;
            case "SIZE":
                paddle1Height = PADDLE_HEIGHT * 2;
                paddle2Height = PADDLE_HEIGHT * 2;
                Timer sizeTimer = new Timer(5000, e -> {
                    paddle1Height = PADDLE_HEIGHT;
                    paddle2Height = PADDLE_HEIGHT;
                });
                sizeTimer.setRepeats(false);
                sizeTimer.start();
                break;
            case "SLOW":
                ballSpeedMultiplier = 0.5f;
                Timer slowTimer = new Timer(5000, e -> ballSpeedMultiplier = 1.0f);
                slowTimer.setRepeats(false);
                slowTimer.start();
                break;
        }
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Draw background with gradient
        GradientPaint gradient = new GradientPaint(0, 0, new Color(0, 0, 50),
                                                  WIDTH, HEIGHT, new Color(50, 0, 50));
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, WIDTH, HEIGHT);
        
        // Draw paddles with glow effect
        g2d.setColor(Color.WHITE);
        g2d.fillRect(50, paddle1Y, PADDLE_WIDTH, paddle1Height);
        g2d.fillRect(WIDTH - 50 - PADDLE_WIDTH, paddle2Y, PADDLE_WIDTH, paddle2Height);
        
        // Draw ball with color cycling
        currentBallColor = new Color(
            (int)(Math.sin(System.currentTimeMillis() * 0.002) * 127 + 128),
            (int)(Math.sin(System.currentTimeMillis() * 0.003) * 127 + 128),
            (int)(Math.sin(System.currentTimeMillis() * 0.004) * 127 + 128)
        );
        g2d.setColor(currentBallColor);
        g2d.fillOval((int)ballX, (int)ballY, BALL_SIZE, BALL_SIZE);
        
        // Draw power-ups
        for (PowerUp powerUp : powerUps) {
            g2d.setColor(powerUp.color);
            g2d.fillOval(powerUp.x, powerUp.y, 20, 20);
        }
        
        // Draw scores with modern font
        g2d.setFont(new Font("Arial", Font.BOLD, 40));
        g2d.setColor(Color.WHITE);
        g2d.drawString(String.valueOf(score1), WIDTH/4, 50);
        g2d.drawString(String.valueOf(score2), 3*WIDTH/4, 50);
        
        // Draw center line with animation
        g2d.setColor(new Color(255, 255, 255, 100));
        for(int i = 0; i < HEIGHT; i += 30) {
            int alpha = (int)(Math.sin(i * 0.05 + System.currentTimeMillis() * 0.003) * 127 + 128);
            g2d.setColor(new Color(255, 255, 255, alpha));
            g2d.fillRect(WIDTH/2 - 2, i, 4, 15);
        }
    }

    public void actionPerformed(ActionEvent e) {
        movePaddles();
        moveBall();
        checkCollisions();
        checkPowerUpCollisions();
        repaint();
    }

    private void movePaddles() {
        if (wPressed && paddle1Y > 0) paddle1Y -= 5;
        if (sPressed && paddle1Y < HEIGHT - paddle1Height) paddle1Y += 5;
        if (upPressed && paddle2Y > 0) paddle2Y -= 5;
        if (downPressed && paddle2Y < HEIGHT - paddle2Height) paddle2Y += 5;
    }

    private void moveBall() {
        ballX += ballXSpeed * ballSpeedMultiplier;
        ballY += ballYSpeed * ballSpeedMultiplier;
    }

    private void checkCollisions() {
        // Ball collision with top and bottom walls
        if (ballY <= 0 || ballY >= HEIGHT - BALL_SIZE) {
            ballYSpeed = -ballYSpeed;
        }
        
        // Ball collision with paddles
        if (ballX <= 65 && ballY + BALL_SIZE >= paddle1Y && ballY <= paddle1Y + paddle1Height) {
            ballXSpeed = -ballXSpeed * 1.1; // Increase speed slightly
            ballYSpeed *= 1.1;
        }
        
        if (ballX >= WIDTH - 65 - BALL_SIZE && ballY + BALL_SIZE >= paddle2Y && ballY <= paddle2Y + paddle2Height) {
            ballXSpeed = -ballXSpeed * 1.1; // Increase speed slightly
            ballYSpeed *= 1.1;
        }
        
        // Score points
        if (ballX <= 0) {
            score2++;
            resetBall();
        }
        if (ballX >= WIDTH - BALL_SIZE) {
            score1++;
            resetBall();
        }
    }

    private void resetBall() {
        ballX = WIDTH / 2 - BALL_SIZE / 2;
        ballY = HEIGHT / 2 - BALL_SIZE / 2;
        ballXSpeed = (Math.random() > 0.5 ? 5 : -5);
        ballYSpeed = (Math.random() > 0.5 ? 5 : -5);
        ballSpeedMultiplier = 1.0f;
        paddle1Height = PADDLE_HEIGHT;
        paddle2Height = PADDLE_HEIGHT;
    }

    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_W) wPressed = true;
        if (e.getKeyCode() == KeyEvent.VK_S) sPressed = true;
        if (e.getKeyCode() == KeyEvent.VK_UP) upPressed = true;
        if (e.getKeyCode() == KeyEvent.VK_DOWN) downPressed = true;
    }

    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_W) wPressed = false;
        if (e.getKeyCode() == KeyEvent.VK_S) sPressed = false;
        if (e.getKeyCode() == KeyEvent.VK_UP) upPressed = false;
        if (e.getKeyCode() == KeyEvent.VK_DOWN) downPressed = false;
    }

    public void keyTyped(KeyEvent e) {}

    public static void main(String[] args) {
        JFrame frame = new JFrame("Modern Pong");
        ModernPong game = new ModernPong();
        frame.add(game);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
} 