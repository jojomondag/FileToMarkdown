import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MultiplayerPong extends JPanel implements ActionListener, KeyListener {
    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;
    private static final int PADDLE_LENGTH = 100;
    private static final int PADDLE_THICKNESS = 15;
    private static final int BALL_SIZE = 20;
    
    // Paddle positions
    private int leftPaddleY = HEIGHT / 2 - PADDLE_LENGTH / 2;    // Player 1
    private int rightPaddleY = HEIGHT / 2 - PADDLE_LENGTH / 2;   // Player 2
    private int topPaddleX = WIDTH / 2 - PADDLE_LENGTH / 2;      // Player 3
    private int bottomPaddleX = WIDTH / 2 - PADDLE_LENGTH / 2;   // Player 4
    
    private double ballX = WIDTH / 2 - BALL_SIZE / 2;
    private double ballY = HEIGHT / 2 - BALL_SIZE / 2;
    private double ballXSpeed = 5;
    private double ballYSpeed = 5;
    
    // Scores for all players
    private int score1 = 0;
    private int score2 = 0;
    private int score3 = 0;
    private int score4 = 0;
    
    // Key states
    private boolean wPressed = false;    // Player 1 up
    private boolean sPressed = false;    // Player 1 down
    private boolean upPressed = false;   // Player 2 up
    private boolean downPressed = false; // Player 2 down
    private boolean aPressed = false;    // Player 3 left
    private boolean dPressed = false;    // Player 3 right
    private boolean leftPressed = false; // Player 4 left
    private boolean rightPressed = false;// Player 4 right

    public MultiplayerPong() {
        System.out.println("MULTIPLAYER PONG - 4 Player Edition");
        System.out.println("----------------------------------");
        System.out.println("An exciting 4-player version of the classic game!");
        System.out.println("\nControls:");
        System.out.println("Player 1 (Left):   W/S keys");
        System.out.println("Player 2 (Right):  Up/Down arrows");
        System.out.println("Player 3 (Top):    A/D keys");
        System.out.println("Player 4 (Bottom): Left/Right arrows\n");
        
        this.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        this.setBackground(Color.BLACK);
        this.setFocusable(true);
        this.addKeyListener(this);
        
        Timer timer = new Timer(16, this);
        timer.start();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Set color scheme
        g2d.setColor(Color.WHITE);
        
        // Draw paddles
        // Left paddle (Player 1) - Red
        g2d.setColor(Color.RED);
        g2d.fillRect(0, leftPaddleY, PADDLE_THICKNESS, PADDLE_LENGTH);
        
        // Right paddle (Player 2) - Blue
        g2d.setColor(Color.BLUE);
        g2d.fillRect(WIDTH - PADDLE_THICKNESS, rightPaddleY, PADDLE_THICKNESS, PADDLE_LENGTH);
        
        // Top paddle (Player 3) - Green
        g2d.setColor(Color.GREEN);
        g2d.fillRect(topPaddleX, 0, PADDLE_LENGTH, PADDLE_THICKNESS);
        
        // Bottom paddle (Player 4) - Yellow
        g2d.setColor(Color.YELLOW);
        g2d.fillRect(bottomPaddleX, HEIGHT - PADDLE_THICKNESS, PADDLE_LENGTH, PADDLE_THICKNESS);
        
        // Draw ball
        g2d.setColor(Color.WHITE);
        g2d.fillOval((int)ballX, (int)ballY, BALL_SIZE, BALL_SIZE);
        
        // Draw scores
        g2d.setFont(new Font("Arial", Font.BOLD, 30));
        
        // Player 1 score (left)
        g2d.setColor(Color.RED);
        g2d.drawString(String.valueOf(score1), 50, HEIGHT/2);
        
        // Player 2 score (right)
        g2d.setColor(Color.BLUE);
        g2d.drawString(String.valueOf(score2), WIDTH-50, HEIGHT/2);
        
        // Player 3 score (top)
        g2d.setColor(Color.GREEN);
        g2d.drawString(String.valueOf(score3), WIDTH/2, 50);
        
        // Player 4 score (bottom)
        g2d.setColor(Color.YELLOW);
        g2d.drawString(String.valueOf(score4), WIDTH/2, HEIGHT-30);
        
        // Draw center lines
        g2d.setColor(new Color(255, 255, 255, 50));
        g2d.drawLine(WIDTH/2, 0, WIDTH/2, HEIGHT);
        g2d.drawLine(0, HEIGHT/2, WIDTH, HEIGHT/2);
    }

    public void actionPerformed(ActionEvent e) {
        movePaddles();
        moveBall();
        checkCollisions();
        repaint();
    }

    private void movePaddles() {
        // Player 1 (Left)
        if (wPressed && leftPaddleY > 0) leftPaddleY -= 5;
        if (sPressed && leftPaddleY < HEIGHT - PADDLE_LENGTH) leftPaddleY += 5;
        
        // Player 2 (Right)
        if (upPressed && rightPaddleY > 0) rightPaddleY -= 5;
        if (downPressed && rightPaddleY < HEIGHT - PADDLE_LENGTH) rightPaddleY += 5;
        
        // Player 3 (Top)
        if (aPressed && topPaddleX > 0) topPaddleX -= 5;
        if (dPressed && topPaddleX < WIDTH - PADDLE_LENGTH) topPaddleX += 5;
        
        // Player 4 (Bottom)
        if (leftPressed && bottomPaddleX > 0) bottomPaddleX -= 5;
        if (rightPressed && bottomPaddleX < WIDTH - PADDLE_LENGTH) bottomPaddleX += 5;
    }

    private void moveBall() {
        ballX += ballXSpeed;
        ballY += ballYSpeed;
    }

    private void checkCollisions() {
        // Ball collision with left paddle (Player 1)
        if (ballX <= PADDLE_THICKNESS && 
            ballY + BALL_SIZE >= leftPaddleY && 
            ballY <= leftPaddleY + PADDLE_LENGTH) {
            ballXSpeed = Math.abs(ballXSpeed) * 1.1;
        }
        
        // Ball collision with right paddle (Player 2)
        if (ballX >= WIDTH - PADDLE_THICKNESS - BALL_SIZE && 
            ballY + BALL_SIZE >= rightPaddleY && 
            ballY <= rightPaddleY + PADDLE_LENGTH) {
            ballXSpeed = -Math.abs(ballXSpeed) * 1.1;
        }
        
        // Ball collision with top paddle (Player 3)
        if (ballY <= PADDLE_THICKNESS && 
            ballX + BALL_SIZE >= topPaddleX && 
            ballX <= topPaddleX + PADDLE_LENGTH) {
            ballYSpeed = Math.abs(ballYSpeed) * 1.1;
        }
        
        // Ball collision with bottom paddle (Player 4)
        if (ballY >= HEIGHT - PADDLE_THICKNESS - BALL_SIZE && 
            ballX + BALL_SIZE >= bottomPaddleX && 
            ballX <= bottomPaddleX + PADDLE_LENGTH) {
            ballYSpeed = -Math.abs(ballYSpeed) * 1.1;
        }
        
        // Score points
        if (ballX <= 0) {
            score2++;
            resetBall();
        }
        if (ballX >= WIDTH - BALL_SIZE) {
            score1++;
            resetBall();
        }
        if (ballY <= 0) {
            score4++;
            resetBall();
        }
        if (ballY >= HEIGHT - BALL_SIZE) {
            score3++;
            resetBall();
        }
    }

    private void resetBall() {
        ballX = WIDTH / 2 - BALL_SIZE / 2;
        ballY = HEIGHT / 2 - BALL_SIZE / 2;
        ballXSpeed = (Math.random() > 0.5 ? 5 : -5);
        ballYSpeed = (Math.random() > 0.5 ? 5 : -5);
    }

    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            // Player 1 controls
            case KeyEvent.VK_W: wPressed = true; break;
            case KeyEvent.VK_S: sPressed = true; break;
            
            // Player 2 controls
            case KeyEvent.VK_UP: upPressed = true; break;
            case KeyEvent.VK_DOWN: downPressed = true; break;
            
            // Player 3 controls
            case KeyEvent.VK_A: aPressed = true; break;
            case KeyEvent.VK_D: dPressed = true; break;
            
            // Player 4 controls
            case KeyEvent.VK_LEFT: leftPressed = true; break;
            case KeyEvent.VK_RIGHT: rightPressed = true; break;
        }
    }

    public void keyReleased(KeyEvent e) {
        switch (e.getKeyCode()) {
            // Player 1 controls
            case KeyEvent.VK_W: wPressed = false; break;
            case KeyEvent.VK_S: sPressed = false; break;
            
            // Player 2 controls
            case KeyEvent.VK_UP: upPressed = false; break;
            case KeyEvent.VK_DOWN: downPressed = false; break;
            
            // Player 3 controls
            case KeyEvent.VK_A: aPressed = false; break;
            case KeyEvent.VK_D: dPressed = false; break;
            
            // Player 4 controls
            case KeyEvent.VK_LEFT: leftPressed = false; break;
            case KeyEvent.VK_RIGHT: rightPressed = false; break;
        }
    }

    public void keyTyped(KeyEvent e) {}

    public static void main(String[] args) {
        JFrame frame = new JFrame("Multiplayer Pong - 4 Players");
        MultiplayerPong game = new MultiplayerPong();
        frame.add(game);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
} 