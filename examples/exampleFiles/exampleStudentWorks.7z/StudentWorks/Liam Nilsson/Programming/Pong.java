import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Pong extends JPanel implements ActionListener, KeyListener {
    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;
    private static final int PADDLE_WIDTH = 15;
    private static final int PADDLE_HEIGHT = 90;
    private static final int BALL_SIZE = 20;
    
    private int paddle1Y = HEIGHT / 2 - PADDLE_HEIGHT / 2;
    private int paddle2Y = HEIGHT / 2 - PADDLE_HEIGHT / 2;
    private double ballX = WIDTH / 2 - BALL_SIZE / 2;
    private double ballY = HEIGHT / 2 - BALL_SIZE / 2;
    private double ballXSpeed = 5;
    private double ballYSpeed = 5;
    
    private int score1 = 0;
    private int score2 = 0;
    
    private boolean upPressed = false;
    private boolean downPressed = false;
    private boolean wPressed = false;
    private boolean sPressed = false;

    public Pong() {
        this.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        this.setBackground(Color.BLACK);
        this.setFocusable(true);
        this.addKeyListener(this);
        
        Timer timer = new Timer(16, this); // approximately 60 FPS
        timer.start();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.WHITE);
        
        // Draw paddles
        g.fillRect(50, paddle1Y, PADDLE_WIDTH, PADDLE_HEIGHT);
        g.fillRect(WIDTH - 50 - PADDLE_WIDTH, paddle2Y, PADDLE_WIDTH, PADDLE_HEIGHT);
        
        // Draw ball
        g.fillOval((int)ballX, (int)ballY, BALL_SIZE, BALL_SIZE);
        
        // Draw scores
        g.setFont(new Font("Arial", Font.BOLD, 30));
        g.drawString(String.valueOf(score1), WIDTH/4, 50);
        g.drawString(String.valueOf(score2), 3*WIDTH/4, 50);
        
        // Draw center line
        for(int i = 0; i < HEIGHT; i += 30) {
            g.fillRect(WIDTH/2 - 5, i, 10, 15);
        }
    }

    public void actionPerformed(ActionEvent e) {
        movePaddles();
        moveBall();
        checkCollisions();
        repaint();
    }

    private void movePaddles() {
        if (wPressed && paddle1Y > 0) {
            paddle1Y -= 5;
        }
        if (sPressed && paddle1Y < HEIGHT - PADDLE_HEIGHT) {
            paddle1Y += 5;
        }
        if (upPressed && paddle2Y > 0) {
            paddle2Y -= 5;
        }
        if (downPressed && paddle2Y < HEIGHT - PADDLE_HEIGHT) {
            paddle2Y += 5;
        }
    }

    private void moveBall() {
        ballX += ballXSpeed;
        ballY += ballYSpeed;
    }

    private void checkCollisions() {
        // Ball collision with top and bottom walls
        if (ballY <= 0 || ballY >= HEIGHT - BALL_SIZE) {
            ballYSpeed = -ballYSpeed;
        }
        
        // Ball collision with paddles
        if (ballX <= 65 && ballY + BALL_SIZE >= paddle1Y && ballY <= paddle1Y + PADDLE_HEIGHT) {
            ballXSpeed = -ballXSpeed;
            ballXSpeed *= 1.1; // Increase speed slightly
        }
        
        if (ballX >= WIDTH - 65 - BALL_SIZE && ballY + BALL_SIZE >= paddle2Y && ballY <= paddle2Y + PADDLE_HEIGHT) {
            ballXSpeed = -ballXSpeed;
            ballXSpeed *= 1.1; // Increase speed slightly
        }
        
        // Score points
        if (ballX <= 0) {
            score2++;
            resetBall();
        }
        if (ballX >= WIDTH - BALL_SIZE) {
            score1++;
            resetBall();
        }
    }

    private void resetBall() {
        ballX = WIDTH / 2 - BALL_SIZE / 2;
        ballY = HEIGHT / 2 - BALL_SIZE / 2;
        ballXSpeed = (Math.random() > 0.5 ? 5 : -5);
        ballYSpeed = (Math.random() > 0.5 ? 5 : -5);
    }

    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_W) wPressed = true;
        if (e.getKeyCode() == KeyEvent.VK_S) sPressed = true;
        if (e.getKeyCode() == KeyEvent.VK_UP) upPressed = true;
        if (e.getKeyCode() == KeyEvent.VK_DOWN) downPressed = true;
    }

    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_W) wPressed = false;
        if (e.getKeyCode() == KeyEvent.VK_S) sPressed = false;
        if (e.getKeyCode() == KeyEvent.VK_UP) upPressed = false;
        if (e.getKeyCode() == KeyEvent.VK_DOWN) downPressed = false;
    }

    public void keyTyped(KeyEvent e) {}

    public static void main(String[] args) {
        JFrame frame = new JFrame("Pong");
        Pong game = new Pong();
        frame.add(game);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
